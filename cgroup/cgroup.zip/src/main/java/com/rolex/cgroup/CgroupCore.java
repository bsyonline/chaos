package com.rolex.cgroup;

/**
 * <P>
 *
 * </p>
 *
 * @author rolex
 * @since 2021
 */
public interface CgroupCore {
    SubSystemType getType();
}
